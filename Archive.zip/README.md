# Google Sheets + AWS Lambda = JSON backend
Create Google Sheets backend with nice JSON api with this Lambda.

### How to install?
1. Publish your Google Sheets to the web.
2. Edit `index.js` and add your Google Sheets key there.
3. Run `npm install` locally, zip the file, and upload it to your Lambda.

For precies instructions, check out [instructions from Medium](https://medium.com/p/d5e67ab4f660/edit)
